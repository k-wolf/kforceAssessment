﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FamousFolks.Controllers
{
    public class FamousController : Controller
    {
        FamousFolksContext db = new FamousFolksContext();

        // GET: Famous
        public ActionResult Index()
        {
            var query = db.Folks.OrderBy(c => c.LastName);
            List<Folk> model = query.ToList();
            return View(model);
        }
    }
}