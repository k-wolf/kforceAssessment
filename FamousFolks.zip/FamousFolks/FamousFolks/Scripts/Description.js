﻿$(function(){
    $('td').click(function(e){
        e.preventDefault();
        $(this).closest('td').find(".des").toggle();
    });
});